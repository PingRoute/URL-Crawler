public class test {
	public static void main(String[] args) {
		String a = "hello";
		System.out.println(a.substring(1));
	}
}
